OIER — Seguridad y Alta Disponibilidad

Sitio educativo dedicado a noticias de ciberseguridad, análisis de incidentes, fuentes contrastables y medidas de prevención y continuidad.

Puesta en marcha
- Abre index.html en un navegador moderno.
- Las páginas utilizan style.css y script.js compartidos.
- Las noticias enlazan a publicaciones externas; para abrirlas se necesita conexión a Internet.
- Los vídeos de la portada están incluidos en la carpeta assets.

Contenido
- Noticias y análisis: contexto del incidente, impacto, medidas y enlaces a fuentes.
- Fuentes: organismos oficiales y recursos técnicos.
- Contenidos y Defensa: conceptos prácticos y situaciones interactivas.
- Análisis de noticias: criterios para seleccionar, contrastar y explicar cada caso.

Las imágenes y escenas audiovisuales de apoyo son ilustrativas. No deben interpretarse como fotografías o grabaciones oficiales de los incidentes descritos.
