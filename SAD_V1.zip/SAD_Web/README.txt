SAD — Seguridad y Alta Disponibilidad

Abrir index.html en un navegador moderno. Las páginas comparten style.css y script.js.

Mejoras de esta versión:
- Noticias reales fechadas y enlazadas a sus fuentes.
- Cada noticia distingue hechos publicados, impacto, medidas y reflexión personal.
- Buscador global en el icono de lupa de la cabecera (también Ctrl+K; Esc cierra).
- Páginas independientes y navegación local.

Nota académica: las reflexiones están redactadas como ejemplo en primera persona; revisa y adapta la valoración para que refleje tu opinión real antes de entregar.

Las imágenes incluidas son recursos visuales temáticos; no representan necesariamente fotografías del incidente. Las noticias enlazan a las fuentes originales.
Actualización visual: las imágenes de las noticias son recreaciones realistas centradas en la situación descrita; no son fotografías oficiales de los incidentes. Tun Tun Sahur se mantiene en portada y la ilustración lateral queda limpia, sin elementos superpuestos.


Vídeos integrados
- Dos vídeos MP4 locales, con controles nativos y descarga directa desde Inicio. No dependen de YouTube y pueden reproducirse sin conexión.
- Son materiales didácticos originales del proyecto; no se presentan como vídeos oficiales de INCIBE.
- La mascota inferior izquierda se muestra sin objetos ni efectos superpuestos.


ACTUALIZACIÓN DE VÍDEOS Y DEFENSA
- La portada integra dos vídeos MP4 locales en assets/videos/. Se reproducen con los controles nativos del navegador y se pueden descargar desde la propia página.
- Los vídeos didácticos se han elaborado específicamente para este proyecto; no se presentan como vídeos oficiales de INCIBE.
- La sección Defensa incluye cinco situaciones interactivas, respuestas justificadas y puntuación final.
- Las fotografías/escenas de las noticias son recreaciones visuales vinculadas al contexto de cada caso, no fotografías de los incidentes reales.


CAMBIOS DE ESTA ENTREGA
- Segunda propuesta con estética morada, conservando contenido y estructura.
- Reproductores Play / Pausa integrados desde YouTube (INCIBE).
- La imagen de phishing seleccionada está en assets/challenge-phishing.jpg.
- La imagen lateral assets/side-mascot.jpg y su CSS de encuadre se conservan del archivo original.
- Abrir index.html con el navegador; los reproductores de YouTube necesitan Internet.
